﻿$(document).ready(function () {
  $(".userSection").hide();
});
